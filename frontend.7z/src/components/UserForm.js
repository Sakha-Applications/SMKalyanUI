import React, { useState } from "react";
import { addUser } from "../services/api";
import { TextField, Button, Box, Typography, Paper } from "@mui/material";
import { useNavigate } from "react-router-dom";  // ✅ Import useNavigate

const UserForm = ({ refreshUsers }) => {
    const navigate = useNavigate();  // ✅ Hook to navigate to another page

    const [name, setName] = useState("");
    const [age, setAge] = useState("");
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState("");

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await addUser({ name, age, email, phone });
            refreshUsers();
            setName(""); setAge(""); setEmail(""); setPhone("");
        } catch (error) {
            console.error("Error adding user", error);
        }
    };

    return (
        <Paper elevation={3} sx={{ padding: 3, maxWidth: 400, margin: "auto" }}>
            <Typography variant="h6">User Registration</Typography>
            <form onSubmit={handleSubmit}>
                <TextField
                    fullWidth
                    margin="normal"
                    label="Name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                />
                <TextField
                    fullWidth
                    margin="normal"
                    label="Age"
                    type="number"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    required
                />
                <TextField
                    fullWidth
                    margin="normal"
                    label="Email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
                <TextField
                    fullWidth
                    margin="normal"
                    label="Phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                />
                <Box mt={2}>
                    <Button type="submit" variant="contained" color="primary" fullWidth>
                        Add User
                    </Button>
                </Box>
            </form>
            <Box mt={2}>
                <Button 
                    variant="outlined" 
                    color="secondary" 
                    fullWidth 
                    onClick={() => navigate("/profile-register")} // ✅ Navigate to Profile Register Form
                >
                    Profile Register
                </Button>
            </Box>
        </Paper>
    );
};

export default UserForm;



