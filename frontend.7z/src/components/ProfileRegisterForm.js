    import React, { useState } from "react";
    import { addUser } from "../services/api";
    import { addProfile } from "../services/api";
    import { Tabs, Tab, Box, TextField, Button, Paper, Typography } from "@mui/material";
    import { FormControl, InputLabel, Select, MenuItem } from "@mui/material";
    import axios from "axios";
    import dayjs from "dayjs"; // Import dayjs for date calculations

    const MultiTabForm = () => {
        const [tabIndex, setTabIndex] = useState(0);
        const [phoneError, setPhoneError] = useState(""); // MODIFIED: New state for phone error
        const [formData, setFormData] = useState({
            name: "", age: "", gender: "", // Basic Details
            dob: "", nationality: "", maritalStatus: "", // Personal Info
            email: "", phone: "", address: "", // Contact Details
            fatherName: "", motherName: "", siblings: "", // Family Details
            qualification: "", occupation: "", experience: "" // Career & Education
        });

        const tabLabels = [
            "Basic Details",
            "Personal Info",
            "Contact Details",
            "Family Details",
            "Career & Education"
        ];

        const handleChange = (e) => {
            const { name, value } = e.target;
            setFormData({ ...formData, [e.target.name]: e.target.value });
        };

        const handleDOBChange = (e) => {
            const dob = e.target.value;
            setFormData({ 
                ...formData, 
                dob: dob, 
                currentAge: calculateAge(dob) // Automatically calculate age
            });
        };
        
        const calculateAge = (dob) => {
            if (!dob) return ""; // If no DOB, return empty
            const birthDate = dayjs(dob);
            const today = dayjs();
            return today.diff(birthDate, "year"); // Calculate age in years
        };
        

        // MODIFIED: New function to validate phone when the field loses focus
    const validatePhone = () => {
        const value = formData.phone;
        if (!/^\d+$/.test(value)) {
            setPhoneError("Only digits are allowed");
        } else if (value.length !== 10) {
            setPhoneError("Phone number must be exactly 10 digits");
        } else {
            setPhoneError("");
        }
    };
        const handleNext = () => {
            if (tabIndex < tabLabels.length - 1) {
                setTabIndex(tabIndex + 1);
            } else {
                alert("This is the last tab");
            }
        };

        const handleBack = () => {
            if (tabIndex > 0) {
                setTabIndex(tabIndex - 1);
            } else {
                alert("This is the first tab");
            }
        };

        const handleSubmit = async () => {
             // MODIFIED: Validate phone number length (must be exactly 10 digits)
        const phoneRegex = /^\d{10}$/;
        if (!phoneRegex.test(formData.phone)) {
            alert("Phone number must be exactly 10 digits.");
            return;
        }
// Send form data to the backend
            try {
                console.log("🟢 Sending profile data to backend:", formData);
        
                const response = await axios.post("http://localhost:3001/api/addProfile", formData);
        
                console.log("✅ Profile created successfully:", response.data);
        
                alert("Profile created successfully!");
                
                 // MODIFIED: Reset form data and navigate back to the first tab after submission
            setFormData({
                name: "", age: "", gender: "",
                dob: "", nationality: "", maritalStatus: "",
                email: "", phone: "", address: "",
                fatherName: "", motherName: "", siblings: "",
                qualification: "", occupation: "", experience: ""
            });
            setTabIndex(0);
            // MODIFIED: After successful submission, redirect to userForm page
           // window.location.href = "/userForm";
           //navigate("/userForm"); // Use navigate instead of window.location.href

            } catch (error) {
                console.error("❌ Error adding profile:", error.response?.data || error.message);
                alert("Failed to create profile.");
            }
        };
        return (
            <Paper elevation={3} sx={{ maxWidth: 500, mx: "auto", p: 3, mt: 4 }}>
                <Typography variant="h5" align="center" gutterBottom>
                    Multi-Tab Form
                </Typography>
                <Tabs value={tabIndex} onChange={(e, newIndex) => setTabIndex(newIndex)} variant="fullWidth">
                    {tabLabels.map((label, index) => (
                        <Tab key={index} label={label} />
                    ))}
                </Tabs>

                <Box sx={{ mt: 2 }}>
                    {tabIndex === 0 && (
                        <>
                            <TextField label="Name" name="name" value={formData.name} onChange={handleChange} fullWidth required />
                            <TextField label="Age" name="age" type="number" value={formData.age} onChange={handleChange} fullWidth required />
                            {/* MODIFIED: Gender field converted to dropdown */}
                        <FormControl fullWidth required>
                            <InputLabel>Gender</InputLabel>
                            <Select
                                name="gender"
                                value={formData.gender}
                                onChange={handleChange}
                            >
                                <MenuItem value="Male">Male</MenuItem>
                                <MenuItem value="Female">Female</MenuItem>
                            </Select>
                        </FormControl>
                    </>
                )}
                {tabIndex === 1 && (
                    <>  </>
                    )}
                    {tabIndex === 1 && (
                        <>
                             <TextField 
            label="Date of Birth" 
            name="dob" 
            type="date" 
            InputLabelProps={{ shrink: true }} 
            value={formData.dob} 
            onChange={handleDOBChange} 
            fullWidth 
            required 
            inputProps={{ 
                max: dayjs().format("YYYY-MM-DD"), // Prevent future dates
            }}
        />
          <TextField 
            label="Current Age" 
            name="currentAge" 
            value={formData.currentAge} 
            onChange={handleChange}
            fullWidth 
            InputProps={{ readOnly: true }} // Make it read-only
        />
                            <TextField label="Nationality" name="nationality" value={formData.nationality} onChange={handleChange} fullWidth required />
                            <TextField label="Marital Status" name="maritalStatus" value={formData.maritalStatus} onChange={handleChange} fullWidth required />
                        </>
                    )}
                    {tabIndex === 2 && (
                        <>
                            <TextField label="Email" name="email" type="email" value={formData.email} onChange={handleChange} fullWidth required />
                            <TextField label="Phone Number" name="phone" type="tel" value={formData.phone} onChange={handleChange} fullWidth required />
                            <TextField label="Address" name="address" value={formData.address} onChange={handleChange} fullWidth required />
                        </>
                    )}
                    {tabIndex === 3 && (
                        <>
                            <TextField label="Father's Name" name="fatherName" value={formData.fatherName} onChange={handleChange} fullWidth required />
                            <TextField label="Mother's Name" name="motherName" value={formData.motherName} onChange={handleChange} fullWidth required />
                            <TextField label="Siblings" name="siblings" value={formData.siblings} onChange={handleChange} fullWidth required />
                        </>
                    )}
                    {tabIndex === 4 && (
                        <>
                            <TextField label="Highest Qualification" name="qualification" value={formData.qualification} onChange={handleChange} fullWidth required />
                            <TextField label="Occupation" name="occupation" value={formData.occupation} onChange={handleChange} fullWidth required />
                            <TextField label="Experience (years)" name="experience" type="number" value={formData.experience} onChange={handleChange} fullWidth required />
                        </>
                    )}
                </Box>
                
                <Box sx={{ display: "flex", justifyContent: "space-between", mt: 2 }}>
                    <Button onClick={handleBack} variant="contained" color="secondary">
                        Back
                    </Button>
                    {tabIndex < 4 ? (
                        <Button onClick={handleNext} variant="contained" color="primary">
                            Next
                        </Button>
                    ) : (
                        <Button variant="contained" color="success" onClick={handleSubmit}>
                            Submit
                        </Button>
                    )}
                </Box>
            </Paper>
        );
    };

    export default MultiTabForm;
