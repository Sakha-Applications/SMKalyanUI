import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const ForgotPasswordScreen = () => {
    const [userIdOrEmail, setUserIdOrEmail] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage('');
        setError('');
        setIsLoading(true);

        try {
            const response = await fetch('http://localhost:3001/api/forgot-password', { // Adjust this URL to your backend endpoint
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ userIdOrEmail }),
            });

            const data = await response.json();

            if (response.ok && data.userId) {
                setMessage(data.message || 'Temporary token generated. Proceed to reset password.');
                // Navigate to the Reset Password screen and pass the userId
                navigate('/reset-password', { state: { userId: data.userId } });
            } else {
                setError(data.error || 'Failed to initiate password reset.');
            }
        } catch (err) {
            setError('An unexpected error occurred.');
            console.error('Error sending password reset request:', err);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="forgot-password-container">
            <h2>Forgot Your Password?</h2>
            <p>Enter your User ID or email address below to initiate the password reset process.</p>
            {message && <div className="message">{message}</div>}
            {error && <div className="error">{error}</div>}
            <form onSubmit={handleSubmit} className="forgot-password-form">
                <div className="form-group">
                    <label htmlFor="userIdOrEmail">User ID or Email:</label>
                    <input
                        type="text"
                        id="userIdOrEmail"
                        value={userIdOrEmail}
                        onChange={(e) => setUserIdOrEmail(e.target.value)}
                        required
                        className="form-control"
                        disabled={isLoading}
                    />
                </div>
                <button type="submit" className="btn btn-primary" disabled={isLoading}>
                    {isLoading ? 'Sending...' : 'Initiate Reset'}
                </button>
                <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => navigate('/login')}
                    disabled={isLoading}
                >
                    Back to Login
                </button>
            </form>
        </div>
    );
};

export default ForgotPasswordScreen;