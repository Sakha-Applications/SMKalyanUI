import React from 'react';
import { useNavigate } from 'react-router-dom';
import useLogin from '../hooks/useLogin'; // Adjust path as needed
import './LoginScreen.css';

const LoginScreen = () => {
    const navigate = useNavigate();
    const {
        userId,
        currentPassword,
        newPassword,
        confirmNewPassword,
        isFirstLogin,
        message,
        error,
        isLoading,
        handleUserIdChange,
        handleCurrentPasswordChange,
        handleNewPasswordChange,
        handleConfirmNewPasswordChange,
        updatePassword,
        login
    } = useLogin();

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (isFirstLogin) {
            const result = await updatePassword();
            if (result.success) {
                // Password updated successfully, user can now log in
                 // Consider navigating to the login page after setting the new password
            navigate('/login')
            }
         else if (result.error) {
            console.error("Password update failed:", result.error);
            // Handle the error, display a message to the user
        }
        } else {
            const result = await login();
            if (result.success) {
                console.log("Login successful, redirecting to home");
                // Redirect to home page after successful login
                setTimeout(() => {
                    navigate('/');
                }, 1000);
            }
            else if (result.error) {
                console.error("Login failed:", result.error);
                // Handle the error, display a message to the user
            }
        }
    };

    const handleForgotPassword = () => {
        // Navigate to the forgot password page
        navigate('/forgot-password');
    };

    return (
        <div className="login-container">
            <h2>Login</h2>
            {message && <div className="message">{message}</div>}
            {error && <div className="error">{error}</div>}
            <form onSubmit={handleSubmit} className="login-form">
                <div className="form-group">
                    <label htmlFor="userId">User ID:</label>
                    <input
                        type="text"
                        id="userId"
                        value={userId}
                        onChange={handleUserIdChange}
                        required
                        className="form-control"
                        disabled={isLoading}
                    />
                </div>

                {isFirstLogin ? (
                    <div className="first-login-fields">
                        <div className="form-group">
                            <label htmlFor="newPassword">New Password:</label>
                            <input
                                type="password"
                                id="newPassword"
                                value={newPassword}
                                onChange={handleNewPasswordChange}
                                required
                                className="form-control"
                                disabled={isLoading}
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="confirmNewPassword">Confirm New Password:</label>
                            <input
                                type="password"
                                id="confirmNewPassword"
                                value={confirmNewPassword}
                                onChange={handleConfirmNewPasswordChange}
                                required
                                className="form-control"
                                disabled={isLoading}
                            />
                        </div>
                        <button 
                            type="submit" 
                            className="btn btn-primary"
                            disabled={isLoading}
                        >
                            {isLoading ? 'Processing...' : 'Set New Password'}
                        </button>
                    </div>
                ) : (
                    <div className="regular-login-field">
                        <div className="form-group">
                            <label htmlFor="currentPassword">Password:</label>
                            <input
                                type="password"
                                id="currentPassword"
                                value={currentPassword}
                                onChange={handleCurrentPasswordChange}
                                required
                                className="form-control"
                                disabled={isLoading}
                            />
                        </div>
                        <button 
                            type="submit" 
                            className="btn btn-primary"
                            disabled={isLoading}
                        >
                            {isLoading ? 'Processing...' : 'Login'}
                        </button>
                        <button
                                type="button"
                                className="btn btn-link"
                                onClick={handleForgotPassword}
                                disabled={isLoading}
                            >
                                Forgot Password?
                            </button>
                    </div>
                )}
            </form>
        </div>
    );
};

export default LoginScreen;