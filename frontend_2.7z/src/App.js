import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ProfileRegisterForm from "./components/ProfileRegisterForm";
import ProfileSearchForm from "./components/ProfileSearchForm";
import ProfilePhotoUploadForm from "./components/ProfilePhotoUploadForm";
import LoginScreen from "./components/LoginScreen"; // Assuming LoginScreen is now in the components directory
import Home from "./components/Home";
import ForgotPasswordScreen from "./components/ForgotPasswordScreen"; // Import the ForgotPasswordScreen component
import ResetPasswordScreen from "./components/ResetPasswordScreen"; // Import the ResetPasswordScreen component


const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/profile-register" element={<ProfileRegisterForm />} />
        <Route path="/profile-search" element={<ProfileSearchForm />} />
        <Route path="/upload-photo" element={<ProfilePhotoUploadForm />} />
        <Route path="/login" element={<LoginScreen />} /> {/* Login Route */}
        <Route path="/forgot-password" element={<ForgotPasswordScreen />} /> {/* Forgot Password Route */}
        <Route path="/reset-password" element={<ResetPasswordScreen />} /> {/* Reset Password Route */}
        
      </Routes>
    </Router>
  );
};

export default App;